---
name: replace-with-skill-name
description: Use this skill when the user needs [具体任务和使用场景]. Also use it when [容易被忽略的相近场景]. Do not use it for [相近但不适用的任务].
license: MIT
compatibility: Requires a file-reading agent; list any additional software or network requirements here.
metadata:
  author: replace-me
  version: "0.1.0"
  status: draft
  portability: portable
---

# 目标

说明这个 Skill 要完成什么，以及成功结果是什么。

# 输入

- 必需输入；
- 可选输入；
- 缺少输入时如何处理。

# 工作流程

1. **Step 1**: 读取并检查输入，不立即修改。
2. **Step 2**: 生成计划、清单或诊断结果。
3. **Step 3**: 按计划执行。
4. **Step 4**: 验证输出。
5. **Step 5**: 生成报告和失败记录。

# 安全边界

- 不执行未经审查的高风险命令；
- 不删除原始文件；
- 不泄露敏感信息；
- 需要人工批准的操作必须暂停；
- 无法判断时保留原状并报告。

# 输出

列出文件名、位置和格式。

# 验收标准

- 明确可检查的成功条件；
- 失败时必须保留诊断信息。

# 参考资料

仅在任务需要时读取：

- `references/...`
- `scripts/...`
- `assets/...`
