# 推文配图规划

配图应帮助读者理解结构和迁移关系，不在图内加入大段结论性文字。每张图独立使用，不拼接。

## 图 1：问题场景——同一 Skill 的多份副本

### 目的

表现同一个 `stata-code-review` Skill 分散在 Claude Code、Codex 和第三个 Agent 的目录中，修改逐渐分叉。

### 构图

- 左侧：用户；
- 中间：三个 Agent；
- 右侧：三个相似但版本号不同的 Skill 文件夹；
- 使用虚线表示手工复制；
- 在文件夹角落显示 `v1.2`、`v1.3`、`v1.2-local`。

### 插入位置

文章开头，提出真实痛点之后。

## 图 2：目标结构——一个公共库，多个 Agent 入口

### 目的

解释「一个权威源文件，多个调用入口」。

### 构图

- 中央：`Shared Skills Library`；
- 内部展示 `SKILL.md`、`scripts/`、`references/`、`assets/`；
- 周围连接 Claude Code、Codex、Other Agent；
- 每条连接标注「link / adapter」；
- 不把 Router 放入本图，避免初学者一开始承担过多概念。

### 插入位置

介绍统一架构之后。

## 图 3：老用户迁移流程

### 目的

展示迁移不是直接搬家，而是「盘点—备份—分类—迁移—接入—验证」。

### 构图

```text
Inventory
→ Backup
→ Classify
→ Move common core
→ Create agent entries
→ Verify
```

- 在 `Classify` 节点向下分出：
  - Portable
  - Needs adapter
  - Agent-specific
  - Project-specific
  - Conflict
- 冲突分支进入人工判断，不直接进入迁移。

### 插入位置

老用户迁移章节。

## 图 4：渐进式升级到 Router

### 目的

说明 Router 不是入门门槛。

### 构图

三级台阶：

```text
Stage 0
公共目录 + 清晰 description

Stage 1
领域分类 + Registry

Stage 2
领域 Router + 多 Skill 编排
```

- 横轴表示 Skills 数量和重叠程度增加；
- 纵轴表示管理复杂度；
- 明确标出 `Router-ready, not Router-first`。

### 插入位置

文章后半部分 Router 章节。

## 图 5：完整生态图(可选)

### 目的

用于文章末尾或讲义章节总结。

### 构图

```text
User Task
→ Agent
→ Skill Discovery
→ Shared Library
→ Scripts / References / Assets
→ Execution Report
```

Registry 和 Router 放在 Skill Discovery 与 Shared Library 之间，以可选模块呈现。

### 使用建议

文章篇幅有限时保留前 4 张；第 5 张用于讲义或课程演示。
