# 任务：验证 Claude Code 与 Codex 是否真正共享同一套 Skills

把本文件交给任一 Agent 执行。该任务只做检查，不修改正式 Skill。

## 目标

确认两个 Agent 的调用入口指向同一个公共源，并验证 Skill 在两个 Agent 中的基本行为。

## 检查范围

选择 3–5 个代表性 Skill：

- 一个纯指令 Skill；
- 一个包含 `references/` 的 Skill；
- 一个包含 `scripts/` 的 Skill；
- 一个带 Agent 专属元数据的 Skill；
- 一个容易与其他 Skill 混淆的 Skill。

## 文件层验证

1. 解析 Claude Code 和 Codex 中的入口路径。
2. 对每个 Skill 比较最终目标的绝对路径。
3. 比较 `SKILL.md` 哈希。
4. 检查相对引用是否能从 Skill 根目录解析。
5. 检查 `name` 与父目录是否一致。
6. 检查 YAML 是否可解析。
7. 检查是否存在绝对路径、密钥、Token 或敏感信息。

## 触发验证

为每个 Skill 准备：

- 3 个应该触发的真实任务；
- 3 个不应该触发的相近任务；
- 1 个显式调用任务。

分别在 Claude Code 和 Codex 中测试，记录：

```text
Agent
Skill
Prompt
Expected
Actual
Triggered
Output acceptable
Notes
```

## 行为验证

检查两个 Agent 是否：

- 读取了相同公共核心；
- 按要求读取参考文件；
- 未在不需要时执行高风险脚本；
- 生成了规定输出；
- 遵守了禁止事项；
- 失败时保留日志。

## 回滚条件

出现以下任一情况时，不得删除旧副本：

- 任一 Agent 无法发现 Skill；
- 同名 Skill 被其他目录覆盖；
- `description` 频繁误触发；
- Agent 专属字段导致另一 Agent 解析失败；
- 相对路径无法解析；
- 输出质量明显下降。

## 输出

生成：

```text
reports/shared-skills-verification.md
reports/trigger-evaluation.json
```

报告结论只能使用：

- `PASS`
- `PASS_WITH_LIMITATIONS`
- `FAIL`

只有 `PASS` 或用户接受限制后的 `PASS_WITH_LIMITATIONS`，才可以进入旧副本清理阶段。
