# 多 Agent 共享 Skills：读者执行材料

这套材料用于把 Claude Code、Codex 或其他 Agent 中已有的 Skills，整理到一个统一的公共目录中。完成后，同一 Skill 只保留一份权威源文件，不同 Agent 通过各自的发现目录访问它。

## 适用对象

- 目前只使用 Claude Code，准备增加 Codex；
- 目前只使用 Codex，准备增加 Claude Code；
- 两个 Agent 都在使用，但已经出现重复 Skills；
- 刚开始使用 Agent，希望从第一天采用统一管理；
- Skills 数量增加后，准备引入 Registry 或 Router。

## 推荐目标结构

```text
agent-skills/
├── skills/                  # 唯一权威来源
│   ├── stata/
│   ├── python/
│   ├── academic-writing/
│   ├── github/
│   └── course-production/
├── registry/
│   └── skills.yaml          # 简单登记表，初期可以很轻量
├── adapters/
│   ├── claude-code/
│   └── codex/
├── reports/                 # 盘点、迁移和验证报告
├── backups/                 # 迁移备份，建议加入 .gitignore
└── router/
    └── README.md            # 预留接口，初期不必启用
```

推荐默认位置：

```text
Windows:       %USERPROFILE%\agent-skills
macOS/Linux:   ~/agent-skills
```

用户可以改用其他磁盘或目录，但后续所有 Agent 都必须指向同一个公共根目录。

## 核心规则

1. **一个权威源文件**：正式 Skill 只在公共库的 `skills/` 中编辑。
2. **多个调用入口**：Claude Code 和 Codex 的默认目录只保存链接或轻量适配器。
3. **先盘点，后修改**：Agent 不得在没有清单和备份的情况下直接移动文件。
4. **不自动删除冲突项**：名称相同但内容不同的 Skill 必须进入人工审查清单。
5. **公共核心优先**：优先使用开放的 `SKILL.md` 格式，减少 Agent 专属字段。
6. **专属增强隔离**：确实依赖某个 Agent 的能力时，使用薄适配层，不复制整套任务逻辑。
7. **迁移必须可逆**：旧目录至少保留到双 Agent 验证通过。
8. **外部 Skill 先审查**：从 GitHub 等来源下载的 Skill 要记录来源、版本、许可证和风险。
9. **敏感信息不得进入 Skill**：API Key、密码、Token、私人路径和个人数据应放在环境变量或本地配置中。
10. **Router-ready, not Router-first**：目录和元数据为 Router 预留接口，但 Skills 较少时不强制部署 Router。

## 如何选择任务文档

- 从零搭建：使用 `01-build-from-scratch.md`
- 从 Claude Code 迁移：使用 `02-migrate-from-claude-code.md`
- 从 Codex 迁移：使用 `03-migrate-from-codex.md`
- 两边都有 Skills：使用 `04-audit-and-merge-two-sources.md`
- 让 Claude Code 接入公共库：使用 `05-connect-claude-code.md`
- 让 Codex 接入公共库：使用 `06-connect-codex.md`
- 做最终检查：使用 `07-verify-shared-skills.md`
- 接入其他 Agent：使用 `08-connect-another-agent.md`
- Skills 规模扩大后升级：使用 `09-router-upgrade-guide.md`
- 创建新 Skill：使用 `templates/SKILL.md`
- 登记 Skills：使用 `templates/skills.yaml`

## 推荐执行顺序

### 新用户

```text
01 → 05 → 06 → 07
```

### 原来使用 Claude Code，现在加入 Codex

```text
02 → 05 → 06 → 07
```

### 原来使用 Codex，现在加入 Claude Code

```text
03 → 06 → 05 → 07
```

### 两边都已经积累 Skills

```text
04 → 人工处理冲突 → 05 → 06 → 07
```

## 官方资料

- Agent Skills specification: https://agentskills.io/specification
- Claude Code Skills: https://code.claude.com/docs/en/skills
- Codex Skills: https://developers.openai.com/codex/skills
