# 任务：让 Claude Code 接入公共 Skills 库

把本文件交给 Claude Code 执行。目标不是复制公共 Skills，而是在 Claude Code 的发现目录中建立安全入口。

## 前提

公共库已经存在：

```text
<PUBLIC_SKILLS_ROOT>/skills/
```

Claude Code 个人发现目录通常为：

```text
~/.claude/skills/
```

## 原则

- 按 Skill 分别建立链接，不替换整个 `~/.claude/skills/`。
- 保留原有 Claude Code 专属 Skills。
- 链接名与 Skill 目录名一致。
- 如果发现同名真实目录，不覆盖，列入冲突报告。
- Windows 优先使用不要求管理员权限的目录 Junction；条件允许时也可使用符号链接。
- macOS/Linux 使用符号链接。
- 在创建链接前先做 dry run。

## 执行步骤

1. 检测 Claude Code 版本。确认其版本支持 Skill 目录链接；如果不支持，停止并报告升级建议。
2. 枚举 `<PUBLIC_SKILLS_ROOT>/skills/` 下所有包含 `SKILL.md` 的 Skill 目录。
3. 生成 dry-run 表：

```text
Skill name | Source path | Proposed Claude path | Status
```

4. 检查目标：
   - 不存在：可以创建；
   - 已是指向同一来源的链接：跳过；
   - 是失效链接：报告；
   - 是指向其他来源的链接：冲突；
   - 是真实目录：冲突，不覆盖。
5. 用户批准 dry run 后创建入口。

### Windows

优先选择：

```powershell
New-Item -ItemType Junction `
    -Path "$HOME\.claude\skills\<skill-name>" `
    -Target "<PUBLIC-SKILLS-PATH>"
```

如果环境支持且用户允许，也可以使用目录符号链接。不要以管理员权限作为默认前提。

### macOS / Linux

```bash
ln -s "<PUBLIC-SKILLS-PATH>" \
      "$HOME/.claude/skills/<skill-name>"
```

6. 创建后验证：
   - 链接目标存在；
   - 目标中有 `SKILL.md`；
   - `name` 与目录名一致；
   - Claude Code 能列出或显式调用该 Skill。
7. 不修改公共 Skill 内容。
8. 输出：
   `reports/claude-connection-report.md`

## 验收标准

- 没有覆盖原有真实目录；
- 所有新入口均指向公共库；
- 至少完成一个 Skill 的显式调用测试；
- 记录失败项和解决建议。
