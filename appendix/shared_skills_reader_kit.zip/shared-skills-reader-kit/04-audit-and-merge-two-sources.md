# 任务：审查并合并 Claude Code 与 Codex 两套 Skills

适用于 `.claude/skills/` 和 `.agents/skills/` 中都已经存在 Skills 的用户。把本文件交给任意一个能够访问两个目录的 Agent。

## 目标

生成双来源差异报告，把完全相同的条目安全合并，把内容冲突的条目留给人工判断。

## 禁止事项

- 不直接选择「最后修改时间较新」的一份作为正式版本。
- 不自动删除任一来源。
- 不覆盖名称相同但哈希不同的 Skill。
- 不执行 Skill 中的脚本。
- 不把 Agent 专属元数据误判为重复内容。
- 不修改项目级 Skills。
- 不在审查阶段创建链接。

## 执行步骤

1. 扫描：
   - `~/.claude/skills/`
   - `$HOME/.agents/skills/`
2. 以 `name`、目录名、`description`、文件哈希和正文相似度建立配对。
3. 将条目分为：
   - 完全相同；
   - 核心相同，仅 Agent 专属文件不同；
   - 名称相同，正文不同；
   - 名称不同，功能高度相似；
   - 只存在于 Claude Code；
   - 只存在于 Codex；
   - 格式异常。
4. 对「核心相同，仅专属文件不同」的条目，建议采用：
   - 一个公共 `SKILL.md`；
   - 保留 `agents/openai.yaml` 等专属元数据；
   - Claude Code 专属设置进入 `adapters/claude-code/`。
5. 对正文冲突项生成逐段差异，不自动合并。
6. 生成：
   - `reports/two-source-audit.md`
   - `reports/two-source-audit.json`
   - `reports/manual-decisions.md`
7. `manual-decisions.md` 应为每个冲突项提供：
   - 两个来源；
   - 差异摘要；
   - 推荐处理方案；
   - 风险；
   - 用户决策占位符。
8. 完成报告后停止。只有用户完成冲突决策后，才能进入迁移。

## 输出示例

```yaml
skill: stata-code-review
classification: same-core-agent-specific-metadata
claude_path: ...
codex_path: ...
recommended_action: merge-common-core
manual_confirmation_required: false
```

```yaml
skill: academic-writing
classification: same-name-different-content
recommended_action: manual-review
manual_confirmation_required: true
```
