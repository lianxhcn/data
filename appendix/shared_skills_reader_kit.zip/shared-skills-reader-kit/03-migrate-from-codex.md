# 任务：把 Codex Skills 迁移到公共库

把本文件交给 Codex 执行。该任务先盘点，再备份和迁移。

## 当前来源

Codex 个人 Skills 通常位于：

```text
$HOME/.agents/skills/
```

Codex 还会扫描仓库中的 `.agents/skills/`。本任务默认只迁移用户级 Skills；项目级 Skills 只盘点，不自动变成全局 Skill。

## 目标

把可以跨 Agent 使用的个人 Skills 迁移到：

```text
<PUBLIC_SKILLS_ROOT>/skills/
```

Codex 的 `$HOME/.agents/skills/` 最终只保留指向公共 Skill 的链接或必要的薄适配器。

## 安全边界

- 不删除原文件。
- 先生成盘点报告，再请求用户批准。
- 名称相同但内容不同的 Skill 不自动覆盖。
- 不执行 Skill 附带脚本。
- 不把项目级 Skill 自动提升为个人全局 Skill。
- `agents/openai.yaml` 视为 Codex 专属增强，公共核心与其分开管理。
- 不读取或复制凭据和敏感环境文件。

## Phase A：只读盘点

1. 检测 Codex 版本、操作系统和用户主目录。
2. 扫描 `$HOME/.agents/skills/`。
3. 对每个 Skill 记录：
   - 名称与路径；
   - `SKILL.md` 是否存在；
   - `name`、`description` 是否合规；
   - 是否含 `agents/openai.yaml`；
   - 是否含脚本和外部依赖；
   - 是否使用绝对路径；
   - 是否疑似项目专属；
   - 重名项、哈希和最后修改时间。
4. 分类：
   - A：可直接共享；
   - B：公共核心 + Codex 适配；
   - C：Codex 专属；
   - D：项目专属；
   - E：异常或待人工判断。
5. 生成：

```text
<PUBLIC_SKILLS_ROOT>/reports/codex-inventory.md
<PUBLIC_SKILLS_ROOT>/reports/codex-inventory.json
```

6. Phase A 完成后停止，等待用户批准。

## Phase B：备份与迁移

1. 备份到：

```text
<PUBLIC_SKILLS_ROOT>/backups/codex-skills-<YYYYMMDD-HHMMSS>/
```

2. A 类 Skill 复制到公共库并校验格式。
3. B 类 Skill：
   - `SKILL.md` 保留公共工作流程；
   - `agents/openai.yaml` 可以随 Skill 保存，但必须登记为 Codex 专属元数据；
   - 其他专属说明写入 `adapters/codex/`。
4. C、D、E 类只记录，不自动迁移。
5. 更新 `registry/skills.yaml`。
6. 生成 `reports/codex-migration-report.md`。
7. 不删除旧目录，等待双 Agent 验证。

## 成功标准

- 已备份；
- 公共核心和 Codex 专属元数据边界清楚；
- 没有覆盖冲突项；
- 生成盘点与迁移报告；
- 可以继续执行 Claude Code 和 Codex 接入任务。
