# 任务：把 Claude Code Skills 迁移到公共库

把本文件交给 Claude Code 执行。该任务分为「盘点」和「迁移」两阶段。没有完成盘点报告和备份前，不得移动文件。

## 当前来源

Claude Code 个人 Skills 通常位于：

```text
~/.claude/skills/
```

项目 Skills 可能位于各项目中的：

```text
.claude/skills/
```

本任务默认只迁移个人 Skills。项目级 Skills 只盘点，不自动迁移到全局库。

## 目标

把可以跨 Agent 使用的个人 Skills 迁移到：

```text
<PUBLIC_SKILLS_ROOT>/skills/
```

Claude Code 的原发现目录最终只保留指向公共 Skill 的链接或必要的薄适配器。

## 安全边界

- 先盘点，后备份，最后迁移。
- 不删除原目录。
- 名称相同但内容不同的 Skill 不自动合并。
- 不把项目专属规则迁移到全局库。
- 不自动移除 Claude Code 专属字段。
- 不把 `.claude/commands/` 直接当作标准 Skill；先单独分类。
- 不修改无法解析的 YAML，先列入异常清单。
- 不执行 Skill 中附带的脚本。
- 不读取或复制密钥、Token、`.env` 或凭据文件。

## Phase A：只读盘点

1. 检测 Claude Code 版本和操作系统。
2. 扫描：
   - `~/.claude/skills/`
   - `~/.claude/commands/`
3. 对每个条目记录：
   - 名称；
   - 绝对路径；
   - 是否包含 `SKILL.md`；
   - `name` 与目录名是否一致；
   - `description` 是否存在；
   - 是否包含 `scripts/`、`references/`、`assets/`；
   - 是否使用 Claude Code 专属字段或动态语法；
   - 是否包含绝对路径；
   - 是否疑似项目专属；
   - 是否与其他 Skill 重名；
   - 最后修改时间；
   - 文件哈希；
   - 建议分类。
4. 生成：

```text
<PUBLIC_SKILLS_ROOT>/reports/claude-inventory.md
<PUBLIC_SKILLS_ROOT>/reports/claude-inventory.json
```

5. 将条目分为：
   - A：可直接共享；
   - B：需要轻量适配；
   - C：Claude Code 专属；
   - D：项目专属；
   - E：异常或待人工判断。
6. 完成 Phase A 后停止，并向用户展示摘要。未得到用户继续执行的明确指令时，不进入 Phase B。

## Phase B：备份与迁移

仅在用户批准盘点结果后执行。

1. 将原个人 Skills 完整复制到：

```text
<PUBLIC_SKILLS_ROOT>/backups/claude-skills-<YYYYMMDD-HHMMSS>/
```

2. 对 A 类 Skill：
   - 复制到公共库的适当领域目录；
   - 保留相对目录结构；
   - 校验 `name` 与父目录一致；
   - 不增加 Agent 专属字段。
3. 对 B 类 Skill：
   - 抽取开放格式的公共核心；
   - 把 Claude Code 专属说明写入：
     `adapters/claude-code/<skill-name>.md`
   - 如必须使用薄包装 Skill，明确标注其公共核心路径。
4. C、D、E 类不自动迁移，只写入报告。
5. 更新 `registry/skills.yaml`，至少登记：
   - `name`
   - `path`
   - `domain`
   - `source`
   - `status`
   - `portability`
   - `last_reviewed`
6. 不删除原 Skill。将迁移状态写入：
   `reports/claude-migration-report.md`
7. 提醒用户下一步运行：
   - `05-connect-claude-code.md`
   - `06-connect-codex.md`
   - `07-verify-shared-skills.md`

## 成功标准

- 原目录有时间戳备份；
- 公共 Skill 与原文件内容可追溯；
- 冲突项没有被自动覆盖；
- 公共核心没有不必要的 Claude Code 专属语法；
- 生成了完整迁移报告。
