# Router 升级指南：预留接口，但不要过早复杂化

## 基本判断

公共目录应该从第一天就具备可扩展结构，但普通用户不必在只有少量 Skills 时部署复杂 Router。

推荐原则：

> Router-ready, not Router-first.

## Stage 0：直接发现

适用情形：

- Skills 较少；
- 名称和功能边界清楚；
- 很少需要组合多个 Skills。

主要工作：

- 使用唯一、稳定的 `name`；
- 写清楚 `description` 中的适用与不适用场景；
- 维护简单 `registry/skills.yaml`；
- 为每个 Skill 准备触发与不触发测试。

## Stage 1：领域分类

出现以下现象时升级：

- 同一领域已有较多 Skills；
- 名称开始相近；
- Agent 经常漏选或误选；
- 不同任务只需要看到部分 Skills。

做法：

```text
skills/
├── stata/
├── python/
├── causal-inference/
├── academic-writing/
└── repository-maintenance/
```

Registry 增加：

```yaml
domain:
task_types:
keywords:
status:
portability:
risk_level:
```

## Stage 2：领域 Router

出现以下现象时升级：

- Skills 达到上百个；
- Agent 的候选目录变得拥挤；
- 同一任务常需多个 Skill；
- 需要基于工具、权限或环境过滤。

路由过程：

```text
用户任务
→ 识别领域
→ 读取该领域 Registry
→ 返回少量候选 Skill
→ Agent 选择并激活
```

Router 初期可以是一个普通 Skill，不必开发复杂软件。

## Stage 3：多 Skill 编排

出现以下需求时升级：

- 任务包含盘点、执行、验证和写作多个阶段；
- 不同 Skill 有明确先后依赖；
- 需要失败回滚；
- 需要调用日志和效果评价。

Router 应输出执行计划：

```yaml
task:
selected_skills:
execution_order:
dependencies:
approval_points:
rollback:
expected_outputs:
```

## 不建议的做法

- 一开始就开发向量数据库和复杂检索服务；
- 把上千个 Skill 全部无差别暴露给每个 Agent；
- 让 Router 自动修改所有 Skill；
- 没有版本、状态和权限信息就做自动编排；
- 把 Router 当作公共目录的替代品。

## 最小 Router 预留

即使尚未启用 Router，也建议从第一天保留：

```text
registry/skills.yaml
router/README.md
reports/
```

并为 Skill 登记：

```yaml
name:
path:
description:
domain:
status:
portability:
risk_level:
last_reviewed:
```
