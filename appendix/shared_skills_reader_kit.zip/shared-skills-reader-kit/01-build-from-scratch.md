# 任务：从零建立跨 Agent 公共 Skills 库

把本文件直接交给你正在使用的 Agent。执行前，将文中的 `<PUBLIC_SKILLS_ROOT>` 替换为目标路径；也可以让 Agent 根据操作系统采用默认路径。

## 目标

在本机建立一个与具体 Agent 无关的公共 Skills 仓库，并为后续接入 Claude Code、Codex 及其他 Agent 做好准备。

默认路径：

```text
Windows:       %USERPROFILE%\agent-skills
macOS/Linux:   ~/agent-skills
```

## 约束

- 不删除任何现有文件。
- 不修改系统级目录。
- 不写入密码、API Key、Token 或其他敏感信息。
- 不假定用户具有管理员权限。
- 不创建复杂 Router；只预留 `registry/` 和 `router/`。
- 如目标目录已存在，先检查内容，不覆盖已有文件。
- 所有操作写入 `reports/bootstrap-report.md`。

## 执行步骤

1. 检测操作系统、Shell、用户主目录和 Git 是否可用。
2. 确定 `<PUBLIC_SKILLS_ROOT>`。若用户未指定，则采用默认路径。
3. 创建以下目录：

```text
<PUBLIC_SKILLS_ROOT>/
├── skills/
│   ├── stata/
│   ├── python/
│   ├── academic-writing/
│   ├── github/
│   └── course-production/
├── registry/
├── adapters/
│   ├── claude-code/
│   └── codex/
├── reports/
├── backups/
├── router/
└── templates/
```

4. 创建 `.gitignore`，至少排除：

```gitignore
backups/
*.log
.env
.env.*
secrets/
```

5. 创建 `registry/skills.yaml`，初始内容为：

```yaml
schema_version: "1"
skills: []
```

6. 创建 `router/README.md`，说明 Router 暂未启用；未来只在 Skills 数量和重叠程度明显增加后升级。
7. 创建一个最小示例 Skill：

```text
skills/general/shared-skills-check/
└── SKILL.md
```

其内容应符合开放 Agent Skills 格式，只使用公共字段 `name`、`description`、`license`、`compatibility` 和 `metadata`。
8. 若目录尚未由 Git 管理，执行 `git init`。不要自动提交，除非用户明确要求。
9. 输出 `reports/bootstrap-report.md`，记录：
   - 操作系统；
   - 公共目录；
   - 已创建文件；
   - 跳过的已有文件；
   - 需要用户确认的事项；
   - 下一步应执行的接入文档。

## 验收标准

- 公共目录结构完整；
- 没有覆盖已有文件；
- 至少有一个合法的 `SKILL.md`；
- `registry/skills.yaml` 可以被 YAML 解析器读取；
- `reports/bootstrap-report.md` 已生成；
- 尚未修改 `.claude/skills/` 或 `.agents/skills/`。
