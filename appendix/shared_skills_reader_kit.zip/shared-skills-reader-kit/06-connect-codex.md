# 任务：让 Codex 接入公共 Skills 库

把本文件交给 Codex 执行。目标是在 Codex 用户级发现目录中建立公共 Skills 的入口。

## 前提

公共库：

```text
<PUBLIC_SKILLS_ROOT>/skills/
```

Codex 用户级发现目录：

```text
$HOME/.agents/skills/
```

## 原则

- 不复制公共 Skill；
- 不替换整个 `$HOME/.agents/skills/`；
- 每个 Skill 分别建立链接；
- 不覆盖现有真实目录；
- 先 dry run，后创建；
- 不修改公共核心；
- `agents/openai.yaml` 如存在，按原样保留在 Skill 目录中。

## 执行步骤

1. 检测操作系统和 Codex 版本。
2. 枚举公共库中所有合法 Skill。
3. 生成 dry-run 清单。
4. 检查同名目标的类型和链接来源。
5. 用户批准后创建链接。

### Windows

```powershell
New-Item -ItemType Junction `
    -Path "$HOME\.agents\skills\<skill-name>" `
    -Target "<PUBLIC-SKILLS-PATH>"
```

### macOS / Linux

```bash
ln -s "<PUBLIC-SKILLS-PATH>" \
      "$HOME/.agents/skills/<skill-name>"
```

6. 验证：
   - 链接可以解析；
   - `SKILL.md` 可读取；
   - Codex 能发现该 Skill；
   - 显式调用和隐式触发至少各测试一次；
   - 如变更没有出现，按官方建议重启 Codex 后复测。
7. 输出：
   `reports/codex-connection-report.md`

## 验收标准

- 未覆盖旧目录；
- 入口均指向公共源；
- Skill 可以被 Codex 发现；
- 记录隐式触发与显式调用结果；
- 失败项有明确原因。
